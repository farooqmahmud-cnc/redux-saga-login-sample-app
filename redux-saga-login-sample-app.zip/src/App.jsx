import React from 'react';
import LoginForm from './features/auth/LoginForm';

function App() {
  return (
    <div>
      <LoginForm />
    </div>
  );
}

export default App;
